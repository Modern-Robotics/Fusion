from setuptools import setup

setup(
	name = "Display",
	version = "1.1.0",
	author = "Boxlight",
	author_email = "support@modernroboticsinc.com",
	description = "A Python module to control the connect display",
	packages = ["Display"],
	package_data={"Display": [
		"assets/**/*",
    	"assets/fonts/**/*",
        "assets/images/**/*",
		"assets/icons/**/*"
    ]},
)