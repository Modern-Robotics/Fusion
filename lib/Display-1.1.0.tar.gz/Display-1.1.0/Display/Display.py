import os
import time
from diskcache import Cache
from enum import Enum
from lcddisplay import LCD_2inch
from PIL import Image, ImageDraw, ImageFont
import subprocess

DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "assets")
DEFAULT_ROTATION = 180
STATUS_BAR_HEIGHT = 33
CONTENT_AREA_HEIGHT = 207

# Create a cache object with a directory to store the cache data
cache = Cache(directory='/tmp/mybot')

FACE_IMAGE_FILENAMES = {
	"straight": "straight.jpg",
	"straight-2": "straight-2.jpg",
	"left": "left.jpg",
	"left-2": "left-2.jpg",
	"right": "right.jpg",
	"right-2": "right-2.jpg",
	"crash": "crash.jpg",
	"crash-2": "crash-2.jpg",
	"snooze": "snooze.jpg",
	"snooze-2": "snooze-2.jpg",
}

EMOJI_IMAGE_FILENAMES = {
	"crash": "Crash.jpg",
	"eyes_closed": "EyesClosed.jpg",
	"eyes_left": "EyesLeft.jpg",
	"eyes_right": "EyesRight.jpg",
	"snooze": "Snooze.jpg",
	"eyes_straight": "Straight.jpg",
}

FONT_TYPES = {
	"FreeSans": "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
	"FreeMono": "/usr/share/fonts/truetype/freefont/FreeMono.ttf",
	"FreeSerif": "/usr/share/fonts/truetype/freefont/FreeSerif.ttf",
}

ICON_FILENAMES = {
	"battery": "battery.jpg",
	"clock": "clock.jpg",
	"globe": "globe.jpg",
	"play": "play.jpg",
	"wifi": "wifi.jpg",
}

# Checks the cache for the key, if not found, runs the update function
def get_from_cache(key, update_function):

	if key in cache:
		value = cache.get(key)
	
	else:
		value = update_function()
		
	return value
	

# Initializes display and returns pointer
def initialize_screen():
	display = LCD_2inch.LCD_2inch()
	display.Init()
	display.clear()
	return display
	

# Gets the latest status bar and stores it in the cache
def update_status_bar(battery_status=None, connection_status=None, progress_status=None, network_status=None, time_status=None):

	status_bar = create_status_bar(battery_status, connection_status, progress_status, network_status, time_status)
	cache.set('status_bar', status_bar)
	
	return status_bar


# Creates the status bar
def create_status_bar(battery_status=None, connection_status=None, progress_status=None, network_status=None, time_status=None):

	# Create a new image with a white background
	status_bar = Image.new('RGB', (320, STATUS_BAR_HEIGHT), 'white')

	# Calculate icon positions
	icon_padding = 5
	icon_size = 24

	# Time text position (left)
	time_text_x = icon_padding
	time_text_y = icon_padding

	# Calculate positions for other icons (right)
	right_padding = 320  # total width of the status_bar
	battery_icon_x = right_padding - (icon_padding + icon_size)
	battery_icon_y = icon_padding	
	progress_icon_x = right_padding - (2 * icon_padding + 2 * icon_size)
	progress_icon_y = icon_padding
	connection_icon_x = right_padding - (3 * icon_padding + 3 * icon_size)
	connection_icon_y = icon_padding
	network_icon_x = right_padding - (4 * icon_padding + 4 * icon_size)
	network_icon_y = icon_padding

	# Load image icons
	battery_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", ICON_FILENAMES["battery"]))
	connection_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", ICON_FILENAMES["wifi"]))
	progress_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", ICON_FILENAMES["play"]))
	network_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", ICON_FILENAMES["globe"]))

	# Draw icons on the status bar
	status_bar.paste(battery_icon, (battery_icon_x, battery_icon_y))
	status_bar.paste(connection_icon, (connection_icon_x, connection_icon_y))
	status_bar.paste(progress_icon, (progress_icon_x, progress_icon_y))
	status_bar.paste(network_icon, (network_icon_x, network_icon_y))

	# Draw time text
	draw = ImageDraw.Draw(status_bar)
	font = ImageFont.truetype(FONT_TYPES['FreeSans'], 18)
	time_text = time.strftime("%H:%M", time.localtime())
	draw.text((time_text_x, time_text_y), time_text, font=font, fill=(0, 0, 0))

	return status_bar
	

# Shows a named color (case insesitive) on the display [140 standard names supported]
def show_color(color="white"):

	# Initialize display
	disp = initialize_screen()

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Builds the content section
	content = Image.new('RGB', (320, CONTENT_AREA_HEIGHT), color)

	# Combine the status bar and content sections into a single image
	image = Image.new('RGB', (disp.height, disp.width), 'black')
	image.paste(status_bar, (0, 0))
	image.paste(content, (0, STATUS_BAR_HEIGHT))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)


# Shows a named face [from assets folder] on the display
def show_face(selected_face="straight"):

	# Initialize display
	disp = initialize_screen()

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Create background image
	image = Image.open(os.path.join(DEFAULT_PATH, "images", "faces", FACE_IMAGE_FILENAMES[selected_face]))
	image.paste(status_bar, (0, 0))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)


# Shows a named emoji [from assets folder] on the display
def show_emoji(selected_emoji="eyes_straight"):

	# Initialize display
	disp = initialize_screen()

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Create background image
	image = Image.open(os.path.join(DEFAULT_PATH, "images", "emojis", EMOJI_IMAGE_FILENAMES[selected_emoji]))
	image.paste(status_bar, (0, 0))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)


# Shows text on the display
def show_text(text="Hello World", color="black", background="white", font_type='FreeSans', size=40, position=(40, 90)):

	# Initialize display
	disp = initialize_screen()

	# Get Font
	font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES[font_type]), size)

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Builds the content section
	content = Image.new('RGB', (320, CONTENT_AREA_HEIGHT), background)
	draw = ImageDraw.Draw(content)

	# Add text
	draw.text(position, text, fill=color, font=font)

	# Combine the status bar and content sections into a single image
	image = Image.new('RGB', (disp.height, disp.width), 'black')
	image.paste(status_bar, (0, 0))
	image.paste(content, (0, status_bar.height))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)
	

# Gets the latest version image and stores it in the cache
def update_version():
	
	version = create_version()
	cache.set('version', version)
	
	return version


# Creates a version image from the latest git tag
def create_version():
		
	# Retrieve version
	working_directory = "/usr/Fusion"
	output = subprocess.check_output(['sudo', 'git', '-C', working_directory, 'describe', '--tags', '--abbrev=0'], stderr=subprocess.STDOUT)
	latest_tag = output.strip()
	
	# Get Font
	font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES["FreeSans"]), 14)
	
	# Create Version image
	version = Image.new('RGB', (100, 14), 'white')
	draw = ImageDraw.Draw(version)
	draw.text((0, 0), latest_tag, fill="black", font=font)
	
	return version
	

# Shows a splash screen on the display
def show_splash_screen():

	# Initialize display
	disp = initialize_screen()
	
	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)
	
	# Creates the version image
	version = update_version()

	# Create background image
	image = Image.open(os.path.join(DEFAULT_PATH, "images", "Welcome3.jpg"))
	image.paste(status_bar, (0, 0))
	image.paste(version, (20, 220))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)


# Shows an end screen on the display (meant for when powering off)
def show_end_screen():

	# Initialize display
	disp = initialize_screen()
	
	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)
	
	# Retrieve the last created version image from the cache
	version = get_from_cache('version', update_version)
	
	# Get Font
	font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES["FreeSans"]), 14)
	
	# Retrieve version
	working_directory = "/usr/Fusion"
	output = subprocess.check_output(['sudo', 'git', '-C', working_directory, 'describe', '--tags', '--abbrev=0'], stderr=subprocess.STDOUT)
	latest_tag = output.strip()
	
	# Create Version image
	version = Image.new('RGB', (100, 14), 'white')
	draw = ImageDraw.Draw(version)
	draw.text((0, 0), latest_tag, fill="black", font=font)

	# Create background image
	image = Image.open(os.path.join(DEFAULT_PATH, "images", "Welcome3.jpg"))
	image.paste(status_bar, (0, 0))
	image.paste(version, (20, 220))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)


# Show wifi connection instructions on display
def show_connect_screen(ssid="Recruit_AP123", password="mrirecruit", url="my.bot", font_type="FreeSans", size=25, background="white", color="black"):

	# Initialize display
	disp = initialize_screen()

	# Get Font
	font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES[font_type]), size)

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Builds the content section
	content = Image.new('RGB', (320, CONTENT_AREA_HEIGHT), background)
	draw = ImageDraw.Draw(content)

	# Add text
	draw.text((10, 20), "Connect to Acess Point", fill=color, font=font)
	draw.text((10, 60), "SSID: " + ssid, fill=color, font=font)
	draw.text((10, 100), "Password: " + password, fill=color, font=font)
	draw.text((10, 140), "URL: " + url, fill=color, font=font)

	# Combine the status bar and content sections into a single image
	image = Image.new('RGB', (disp.height, disp.width), 'black')
	image.paste(status_bar, (0, 0))
	image.paste(content, (0, status_bar.height))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)


# Show idle screen when waiting for user input
def show_idle_screen():

	# Initialize display
	disp = initialize_screen()

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Create background image
	image = Image.open(os.path.join(DEFAULT_PATH, "images", "Welcome1.jpg"))
	image.paste(status_bar, (0, 0))

	# Save the current content image in the cache
	cache.set('image', image)

	# Rotate image to reflect robot orientation
	image = image.rotate(DEFAULT_ROTATION)

	# Show image
	disp.ShowImage(image)