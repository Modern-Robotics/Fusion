import os
from diskcache import Cache
from .LCD_2inch import LCD_2inch
from PIL import Image, ImageDraw, ImageFont, ImageColor
import textwrap
import subprocess
import posix_ipc

class RecruitLCD:

	BRAND_PRIMARY_COLOR = "#00ab8f"
	ROBOT_NAME = 'Recruit'
	ICON_DIR_PATH = "/usr/Fusion/FusionServer/Build/public/assets/img/fusion/display/icons"
	FACE_DIR_PATH = "/usr/Fusion/FusionServer/Build/public/assets/img/fusion/display/faces"
	EMOJI_DIR_PATH = "/usr/Fusion/FusionServer/Build/public/assets/img/fusion/display/emojis"
	IMAGE_DIR_PATH = "/usr/Fusion/FusionServer/Build/public/assets/img/fusion/display/images"
	SCREEN_DIR_PATH = "/usr/Fusion/FusionServer/Build/public/assets/img/fusion/display/screens"
	FONT_DIR_PATH = "/usr/share/fonts/truetype/freefont"
	SEMAPHORE_PATH ='/RecruitLCDSemaphore'
	CACHE_PATH = '/tmp/mybot'
	DISPLAY_WIDTH = 320
	DISPLAY_HEIGHT = 240
	
	def __init__(self, rst_pin = 27, dc_pin=25, bl_pin=6):
	
		# Creat Display object with custom GPIO pins
		self.display = LCD_2inch(
			rst=rst_pin,
			dc=dc_pin,
			bl=bl_pin
		)
		
		# Set Header Configuration Options
		self.header_height = 30
		self.header_horizontal_padding = 20
		self.header_horizontal_spacing = 10
		self.header_background_color = 'white'
		self.header_font_size = 20
		self.header_font_type = 'FreeSans'
		self.header_font_color = 'black'
		
		# Set Content Configuration Options
		self.content_background_color = 'white'
		self.content_font_size = 20
		self.content_font_type = 'FreeSans'
		self.content_font_color = 'black'
		self.text_content_padding = 40
		
		# Set Content Configuration Options        
		self.content_height = RecruitLCD.DISPLAY_HEIGHT - self.header_height
		
		# Set Display Orientation
		self.display_rotation = 180
		
		# Set Semaphore
		self.semaphore = self._initialize_semaphore()
		
		# Set Cache object
		self.cache = Cache(directory=RecruitLCD.CACHE_PATH)			
			
	def _initialize_semaphore(self):
		"""Retrieves existing semaphore or creates a new one if missing"""
		
		# Attempt to open the semaphore
		try:
			return posix_ipc.Semaphore(RecruitLCD.SEMAPHORE_PATH)

		# If the semaphore does not exist, then the display has not been initialized
		except posix_ipc.ExistentialError:		

			# Initialize the display
			self.display.Init()

			# Create the semaphore, signaling that the display has been initialized
			return posix_ipc.Semaphore(RecruitLCD.SEMAPHORE_PATH, posix_ipc.O_CREAT, initial_value=1)    
		

	def _create_header(self, status={}):
		"""Creates the image for the header area of the LCD"""  
	
		# Create an image object for the header
		header_img = Image.new('RGB', (RecruitLCD.DISPLAY_WIDTH, self.header_height), self.header_background_color)
		draw = ImageDraw.Draw(header_img)
	
		# Left section: Draw Robot Name
		font = ImageFont.truetype(self._get_font_path(self.header_font_type), self.header_font_size)
		text_width, text_height = draw.textsize(RecruitLCD.ROBOT_NAME, font=font)
		draw.text((self.header_horizontal_padding, (self.header_height - text_height) / 2), RecruitLCD.ROBOT_NAME, fill=self.header_font_color, font=font)
		
		# Right section: Prepare icons
		icons = []
		if 'internet' in status:
			if status["internet"]:
				icons.append(self._load_icon("globe", self.header_font_size, self.header_font_size))
	
		if 'program' in status:
			if status["program"]:
				icons.append(self._load_icon("play", self.header_font_size, self.header_font_size))

		# Based on battery level, choose the right icon
		if 'battery' in status:
			if status["battery"]:
				battery_level = status["battery"]
				if 80 <= battery_level <= 100:
					battery_icon = "battery-full"
				elif 60 <= battery_level < 80:
					battery_icon = "battery-three-quarters"
				elif 40 <= battery_level < 60:
					battery_icon = "battery-half"
				elif 20 <= battery_level < 40:
					battery_icon = "battery-quarter"
				else:
					battery_icon = "battery-empty"
				icons.append(self._load_icon(battery_icon, self.header_font_size, self.header_font_size))
	
		# Dynamically place icons
		icon_x = RecruitLCD.DISPLAY_WIDTH - (len(icons) * (self.header_font_size + self.header_horizontal_spacing)) + self.header_horizontal_spacing - self.header_horizontal_padding
		for icon in icons:
			header_img.paste(icon, (int(icon_x), int((self.header_height - icon.height) / 2)))
			icon_x += icon.width + self.header_horizontal_spacing
			
		return header_img
		
	def _load_icon(self, icon_name, desired_width, desired_height):
		"""Load an icon given its name."""
				
		# Load the original image
		path = self._get_image_path('icon', icon_name)
		original_image = self._load_image_from_path(path)
		
		if original_image is None:
			print("Failed to load image from:", path)
			return None

		# Resize the image in memory
		resized_image = original_image.resize((desired_width, desired_height))

		return resized_image

	def _create_content(self, content_type=None, content_data=None, background_color=None, font_size=None, font_type=None, font_color=None):
		"""Depending on content_type, create an image using PIL."""
		
		handler_methods = {
			'text': self._handle_text,
			'color': self._handle_color,
			'face': self._handle_face,
			'emoji': self._handle_emoji,
			'image': self._handle_image
		}
		
		if content_type in handler_methods:
			if content_type == 'text':
				return handler_methods[content_type](content_data, background_color, font_size, font_type, font_color)
			else:
				return handler_methods[content_type](content_data, background_color)
		else:
			raise ValueError("Unknown content_type: {}".format(content_type))
		
	def _handle_text(self, content_data, background_color, font_size, font_type, font_color):
		"""Handle text content type."""        
		
		# Create image and process
		img = Image.new('RGB', (RecruitLCD.DISPLAY_WIDTH - self.text_content_padding, RecruitLCD.DISPLAY_HEIGHT - self.header_height - self.text_content_padding), color=background_color)
		img = self._process_text(img, content_data, background_color, font_size, font_type, font_color)
		img = self._load_and_center_image(img, background_color)
		
		return img
		
	def _handle_color(self, content_data, background_color):
		"""Handle color content type."""
		
		# Create image using content_data to set the background color
		img = Image.new('RGB', (RecruitLCD.DISPLAY_WIDTH, RecruitLCD.DISPLAY_HEIGHT - self.header_height), color=content_data)
		
		return img
		
	def _handle_face(self, content_data, background_color):
		"""Handle face content type"""
	
		# Load image from path
		path = self._get_image_path('face', content_data)
		
		# Process image
		img = self._load_image_from_path(path)
		img = self._process_image(img, 'face', background_color)        
		img = self._load_and_center_image(img, background_color)
		
		return img
		
	def _handle_emoji(self, content_data, background_color):
		"""Handle emoji content type"""
		
		# Load image from path
		path = self._get_image_path('emoji', content_data)
		
		# Process image
		img = self._load_image_from_path(path)
		img = self._process_image(img, 'emoji', background_color)
		img = self._load_and_center_image(img, background_color)
		
		return img
		
	def _handle_image(self, content_data, background_color):
		"""Handle image content type"""
		
		# Load image from path
		path = self._get_image_path('image', content_data)
		
		# Process image
		img = self._load_image_from_path(path)
		img = self._process_image(img, 'image', background_color)
		img = self._load_and_center_image(img, background_color)
		
		return img
		
	def _process_text(self, img, content_data, background_color, font_size, font_type, font_color):
		"""Create and return an image with the provided text."""
		
		# Font Handling
		font = ImageFont.truetype(self._get_font_path(font_type), font_size)
		
		# Estimate average character width and calculate maximum characters per line
		avg_char_width = sum(font.getsize(char)[0] for char in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz') / 52
		chars_per_line = img.width // avg_char_width
		
		# Adjustment factor
		adjustment_factor = 1.3
		chars_per_line = int(chars_per_line * adjustment_factor)
		
		# The maximum number of characters we want to display on the screen
		max_chars = chars_per_line * (img.height // font_size)  # This is an approximation. Adjust if necessary.
		
		# Check if input is a list
		if isinstance(content_data, list):
			# Convert all elements to string, truncate if total character count exceeds max_chars
			chars_count = 0
			truncated_text = []
			for item in content_data:
				item_str = str(item)
				if chars_count + len(item_str) <= max_chars:
					truncated_text.append(item_str)
					chars_count += len(item_str)
				else:
					remaining_chars = max_chars - chars_count
					truncated_text.append(item_str[:remaining_chars])
					break

			# Wrap each element of the truncated list separately
			wrapped_text = '\n'.join(['\n'.join(textwrap.wrap(item, width=int(chars_per_line))) for item in truncated_text])
		else:
			# Convert the input to a string
			text = str(content_data)
			# If text exceeds maximum characters, truncate it
			if len(text) > max_chars:
				text = text[:max_chars]
			# Wrap the text
			wrapped_text = '\n'.join(textwrap.wrap(text, width=int(chars_per_line)))
			
		# Draw the wrapped and possibly truncated text on the content image
		draw = ImageDraw.Draw(img)
		draw.multiline_text((0, 0), wrapped_text, fill=font_color, font=font)

		return img
		
	def _get_image_path(self, image_type, image_name):
		"""Builds an image path based on the type"""
	
		# Mapping of image type to directory and file extension
		directory_mappings = {
			'face': {'path': RecruitLCD.FACE_DIR_PATH, 'ext': '.jpg'},
			'emoji': {'path': RecruitLCD.EMOJI_DIR_PATH, 'ext': '.png'},
			'image': {'path': RecruitLCD.IMAGE_DIR_PATH, 'ext': '.jpg'},
			'icon': {'path': RecruitLCD.ICON_DIR_PATH, 'ext': '.jpg'},
			'screen': {'path': RecruitLCD.SCREEN_DIR_PATH, 'ext': '.jpg'}
		}

		if image_type not in directory_mappings:
			raise ValueError("Unknown image_type: {}".format(image_type))

		return os.path.join(directory_mappings[image_type]['path'], "{}{}".format(image_name, directory_mappings[image_type]['ext']))
		
	def _get_font_path(self, font_name):
		"""Get the full path of the font file given the font name."""
		
		font_path = os.path.join(RecruitLCD.FONT_DIR_PATH, "{}.ttf".format(font_name))
		
		if not os.path.exists(font_path):
			raise ValueError("Font '{}' not found in directory '{}'".format(font_name, RecruitLCD.FONT_DIR_PATH))
			
		return font_path
		
	def _process_image(self, img, image_type, background_color):
		"""Applies default processing to images based on their type"""
		
		if image_type == 'face':
			return self._resize_and_round_corners(img, scale_factor=0.9, radius=30)
			
		elif image_type == 'emoji':
			return self._resize_and_round_corners(img, scale_factor=0.5, is_emoji=True)
			
		elif image_type == 'image':
			return self._resize_and_crop_image(img)
			
		else:
			raise ValueError("Unknown image_type: {}".format(image_type))
		
	def _load_and_center_image(self, img, background_color):
		"""Centers the img inside the content area"""
		
		# Create content area image
		content = Image.new('RGB', (RecruitLCD.DISPLAY_WIDTH, RecruitLCD.DISPLAY_HEIGHT - self.header_height), color=background_color)
		
		# Create offset for centering
		x_offset = (RecruitLCD.DISPLAY_WIDTH - img.width) // 2
		y_offset = ((RecruitLCD.DISPLAY_HEIGHT - self.header_height) - img.height) // 2
		
		# Paste image
		content.paste(img, (x_offset, y_offset))
		
		return content
		
	def _resize_and_crop_image(self, img):
		"""Resize the image to cover the entire content area while maintaining its aspect ratio."""
		
		width_scale = float(RecruitLCD.DISPLAY_WIDTH) / img.width
		height_scale = float(RecruitLCD.DISPLAY_HEIGHT - self.header_height) / img.height

		# Use the larger of the two as the scaling factor to ensure the image covers the entire area
		scale = max(width_scale, height_scale)
		new_width = int(img.width * scale)
		new_height = int(img.height * scale)
		 
		if img.width != RecruitLCD.DISPLAY_WIDTH or img.height != (RecruitLCD.DISPLAY_HEIGHT - self.header_height):
			img.thumbnail((new_width, new_height), Image.LANCZOS)

		# Crop if the image overflows the dimensions of the LCD after scaling
		left = (img.width - RecruitLCD.DISPLAY_WIDTH) / 2
		top = (img.height - (RecruitLCD.DISPLAY_HEIGHT - self.header_height)) / 2
		right = (img.width + RecruitLCD.DISPLAY_WIDTH) / 2
		bottom = (img.height + (RecruitLCD.DISPLAY_HEIGHT - self.header_height)) / 2
		img = img.crop((left, top, right, bottom))

		return img
			
	def _resize_and_round_corners(self, img, radius=None, scale_factor=1, is_emoji=False):
		"""Resize the image to be slightly smaller and round its corners."""
		
		if is_emoji:
			target_size = 125  # or any suitable size
			img = img.resize((target_size, target_size), Image.ANTIALIAS)
			
		else:
			# The logic for other types of images without Image.ANTIALIAS
			new_width = int(img.width * scale_factor)
			new_height = int(img.height * scale_factor)
			img = img.resize((new_width, new_height))

		if radius:  # Apply rounded corners only if a radius is provided

			# Create a white canvas
			rounded_img = Image.new('RGB', img.size, 'white')
			d = ImageDraw.Draw(rounded_img)
	
			# Create a black mask for the rounded corners
			mask = Image.new('L', img.size, 0)
			d_mask = ImageDraw.Draw(mask)
	
			# Draw the rounded shape on the mask
			d_mask.rectangle([radius, 0, new_width - radius, new_height], fill=255)
			d_mask.rectangle([0, radius, new_width, new_height - radius], fill=255)
			d_mask.ellipse([0, 0, radius*2, radius*2], fill=255)
			d_mask.ellipse([new_width - radius*2, 0, new_width, radius*2], fill=255)
			d_mask.ellipse([0, new_height - radius*2, radius*2, new_height], fill=255)
			d_mask.ellipse([new_width - radius*2, new_height - radius*2, new_width, new_height], fill=255)
	
			# Use the mask to paste the img on the rounded_img
			rounded_img.paste(img, (0, 0), mask)

			return rounded_img
			
		else:
			return img
			
	def _load_image_from_path(self, image_path):
		"""Load an image from the given path."""
		
		try:
			# Open the image
			img = Image.open(image_path)

			# Check if the image has transparency (i.e., an alpha channel)
			if img.mode in ('RGBA', 'LA') or (img.mode == 'P' and 'transparency' in img.info):
				# Create a new image with a white background and the same size as the image
				image_with_bg = Image.new("RGB", img.size, 'white')
				
				# Paste the image onto the background using its alpha channel as a mask
				image_with_bg.paste(img, (0, 0), img)
				img = image_with_bg

			return img
			
		except IOError:
			raise ValueError("Error: Couldn't load the image from {}".format(image_path))

	def _update_display(self, img_type, img):
		"""Updates the displayed image on the LCD"""
		
		# Get last cached image
		container = self.cache.get('cached_image')
		
		# Handles updating content area
		if img_type is 'content':
		
			# If not found create new container
			if container is None:
			
				container = Image.new('RGB', (RecruitLCD.DISPLAY_WIDTH, RecruitLCD.DISPLAY_HEIGHT), 'white')
				header = self._create_header()
				container.paste(header, (0, 0))
				
			container.paste(img, (0, self.header_height))
		
		# Handles updating header area
		elif img_type is 'header':
		
			if container is None:
			
				container = Image.new('RGB', (RecruitLCD.DISPLAY_WIDTH, RecruitLCD.DISPLAY_HEIGHT), 'white')
				content = self._create_content('color', 'white')
				container.paste(content, (0, self.header_height))
				
			container.paste(img, (0, 0))
		   
	   # Handles updating full image 
		elif img_type is 'full':
		
			container = img
		
		# Display image
		self._display_image(container)
		
			
	def _display_image(self, img):
		"""Sends an image to the LCD"""
	
		# Cache image
		self.cache.set('cached_image', img)

		# Rotate the image by 180 degrees
		rotated_image = img.rotate(self.display_rotation)
		
		# Acquire the semaphore, blocking if necessary until it becomes available
		with self.semaphore:
			self.display.ShowImage(rotated_image) # Send image to LCD            

	def available_faces(self):
		"""Gets list of available faces"""
		
		return self._available_files(RecruitLCD.FACE_DIR_PATH)

	def available_emojis(self):
		"""Gets list of available emojis"""
		
		return self._available_files(RecruitLCD.EMOJI_DIR_PATH)

	def available_images(self):
		"""Gets list of available images"""
		
		return self._available_files(RecruitLCD.IMAGE_DIR_PATH)

	def _available_files(self, directory_path):
		"""Fetches available .jpg files in a directory"""
		
		all_files = os.listdir(directory_path)
		valid_files = [os.path.splitext(f)[0] for f in all_files if f.lower()]
		
		return valid_files
		
	def available_fonts(self):
		"""Return a list of available fonts (without the .ttf extension)."""
		
		fonts = []
		for font_file in os.listdir(RecruitLCD.FONT_DIR_PATH):
			if font_file.endswith('.ttf'):
				fonts.append(font_file[:-4])  # remove ".ttf" extension
				
		return fonts

	def update_header(self, status={}):
		"""Creates a header images and updates the display"""
				
		# Create new header
		header = self._create_header(status)
				
		# Send to display
		self._update_display('header', header)
			 
	def update_content(self, content_type, content_data=None, background_color=None, font_size=None, font_type=None, font_color=None):
		"""Creates a content image and updates the display"""
	
		# Set Default configuration variables
		if background_color is None:
			background_color = self.content_background_color
		if font_size is None:
			font_size = self.content_font_size
		if font_type is None:
			font_type = self.content_font_type            
		if font_color is None:
			font_color = self.content_font_color
		
		# Create new content
		content = self._create_content(content_type, content_data, background_color, font_size, font_type, font_color)
		
		# Send to display
		self._update_display('content', content)
		
		
	def show_text(self, text="Hello World", font_size=20, font_color="black", font_type='FreeSans', background_color="white"):
		"""Shows text on the display"""
	
		self.update_content('text', text, background_color=background_color, font_color=font_color, font_size=font_size, font_type=font_type)
		
	def show_color(self, color="white"):
		"""Shows a named color (case insensitive) on the display [140 standard names supported]"""

		self.update_content('color', color)
	
	def show_face(self, selected_face="straight"):
		"""Shows a named face [from assets folder] on the display"""
	
		self.update_content('face', selected_face)
		
	def show_emoji(self, selected_emoji="eyes-straight"):
		"""Shows a named emoji [from assets folder] on the display"""
	
		self.update_content('emoji', selected_emoji)
		
	def show_image(self, selected_image="earth"):
		"""Shows a named image [from assets folder] on the display"""
	
		self.update_content('image', selected_image)
		
	def show_connect_screen(self, ssid="Recruit_AP123", password="bxlrecruit", url="http://my.bot", uap0_address="", wlan0_address=""):
		"""# Show wifi connection instructions on display"""
	
		# Define local variables
		instructions = [
			"Ready to Connect",
			"1. Connect to: " + ssid,
			"2. Enter Password: " + password,
			"3. Open your: web browser",
			"4. Visit: " + url,
			"     or: 192.168.50.1"
		]
		ip_address_image_height = 20
		instructions_font_size = 20
		instructions_header_font_size = 24
		instructions_line_spacing = 15
		ip_address_font_size = 15
		rgb_color = ImageColor.getrgb(RecruitLCD.BRAND_PRIMARY_COLOR)
		
		# Builds the content section
		content_section = Image.new('RGB', (RecruitLCD.DISPLAY_WIDTH, RecruitLCD.DISPLAY_HEIGHT - self.header_height), rgb_color)

		# Create the two new images to be pasted onto the content_section

		# First image will occupy the full height except the last 20 pixels
		instructions_image_height = RecruitLCD.DISPLAY_HEIGHT - self.header_height - ip_address_image_height
		instructions_image = Image.new('RGBA', (RecruitLCD.DISPLAY_WIDTH, instructions_image_height), rgb_color)
		instructions_image_drawer = ImageDraw.Draw(instructions_image)

		# Second image will take the remaining 20 pixels at the bottom
		ip_address_image = Image.new('RGBA', (RecruitLCD.DISPLAY_WIDTH, ip_address_image_height), rgb_color)
		ip_address_image_drawer = ImageDraw.Draw(ip_address_image)

		# Prepare the fonts
		instructions_header_font = ImageFont.truetype(self._get_font_path('FreeSansBold'), instructions_header_font_size)
		instructions_font = ImageFont.truetype(self._get_font_path('FreeSans'), instructions_font_size)
		instructions_bold_font = ImageFont.truetype(self._get_font_path('FreeSansBold'), instructions_font_size)
		ip_address_font = ImageFont.truetype(self._get_font_path('FreeSans'), ip_address_font_size)

		# Draw the instructions on the first image
		text_height = instructions_image_drawer.textsize("Test", font=instructions_font)[1]  # Calculate height of the text
		total_text_height = len(instructions) * text_height + (len(instructions) - 1) * instructions_line_spacing  # Account for spacing
		start_y_position = (instructions_image_height - total_text_height) / 2  # Start drawing from this y-position to center the instructions
		for i, instruction in enumerate(instructions):
			y_position = start_y_position + i * (text_height + instructions_line_spacing)  # Include spacing in the y-position
			if i == 0:
					instructions_image_drawer.text((10, y_position), instruction, fill="white", font=instructions_header_font)
			else:
				if ":" in instruction:
						parts = instruction.split(":", 1)
						instructions_image_drawer.text((10, y_position), parts[0] + ": ", fill="white", font=instructions_font)
						instructions_image_drawer.text((10 + instructions_image_drawer.textsize(parts[0] + ": ", font=instructions_font)[0], y_position), parts[1].strip(), fill="white", font=instructions_bold_font)
				else:
					instructions_image_drawer.text((10, y_position), instruction, fill="white", font=instructions_font)

			# Draw the IP addresses on the second image
			ip_address_image_drawer.text((10, 2), uap0_address, fill="white", font=ip_address_font) 
			ip_address_image_drawer.text((RecruitLCD.DISPLAY_WIDTH - 10 - ip_address_image_drawer.textsize(wlan0_address, font=ip_address_font)[0], 2), wlan0_address, fill="white", font=ip_address_font)

			# Paste the new images onto the content_section
			content_section.paste(instructions_image, (0, 0))
			content_section.paste(ip_address_image, (0, instructions_image_height))
		
			# Send to display
			self._update_display('content', content_section)

	def show_splash_screen(self):
	
		header = self._create_header()

		# Fetch current version and generate image
		#update_version()
		#version_image = create_version_image()
		
		# Retrieve version
		working_directory = "/usr/Fusion"
		fallback_tag = 'v0.0.0'  # Define a fallback tag in case git command fails
		try:
			output = subprocess.check_output(
				['git', '-C', working_directory, 'describe', '--tags', '--abbrev=0'],
				stderr=subprocess.STDOUT
			)
			latest_tag = output.strip()
		except subprocess.CalledProcessError:
			latest_tag = fallback_tag  # Use the fallback tag if git command fails
		
		# Get Font
		font = ImageFont.truetype(self._get_font_path('FreeSans'), 14)		
			
		# Create version image
		version_image = Image.new('RGB', (100, 14), 'white')
		draw = ImageDraw.Draw(version_image)
		draw.text((0, 0), latest_tag, fill='black', font=font)

		# Create background image
		path = self._get_image_path('screen', 'splash')
		splash_screen = Image.open(path)
		splash_screen.paste(header, (0, 0))
		splash_screen.paste(version_image, (20, 210))
		
		# Send to display
		self._update_display('full', splash_screen)
		
	def show_end_screen(self):
	
		self.show_splash_screen()
		
	# Show idle screen
	def show_idle_screen(self):
	
		header = self._create_header()

		# Create the version image
		rgb_color = ImageColor.getrgb(RecruitLCD.BRAND_PRIMARY_COLOR)
		
		# Retrieve version
		working_directory = "/usr/Fusion"
		output = subprocess.check_output(['git', '-C', working_directory, 'describe', '--tags', '--abbrev=0'], stderr=subprocess.STDOUT)
		latest_tag = output.strip()
		
		# Get Font
		font = ImageFont.truetype(self._get_font_path('FreeSans'), 14)
		
			
		# Create version image
		version_image = Image.new('RGB', (100, 14), rgb_color)
		draw = ImageDraw.Draw(version_image)
		draw.text((0, 0), latest_tag, fill='white', font=font)		

		# Create the display image
		path = self._get_image_path('screen', 'idle')
		idle_screen = Image.open(path)
		idle_screen.paste(header, (0, 0))
		idle_screen.paste(version_image, (18, 215))

		# Send to display
		self._update_display('full', idle_screen)