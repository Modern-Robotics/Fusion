import os
import time
from diskcache import Cache
from enum import Enum
from .LCD_2inch import LCD_2inch
from PIL import Image, ImageDraw, ImageFont, ImageColor
import textwrap
import subprocess

DISPLAY_WIDTH = 320
DISPLAY_HEIGHT = 240
DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "assets")
DEFAULT_ROTATION = 180
DEFAULT_FONT = "FreeSans"
STATUS_BAR_HEIGHT = 33
CONTENT_AREA_HEIGHT = 207
BRAND_PRIMARY_COLOR = "#00ab8f"
DISPLAY_FLAG_FILE_PATH = "/tmp/display_initialized.flag"

GPIO_PINS = {
	"RST": 27,
	"DC": 25,
	"BL": 6
}

# Create a cache object with a directory to store the cache data
cache = Cache(directory='/tmp/mybot')

FACE_IMAGE_FILENAMES = {
	"straight": "straight.jpg", 
	"left": "left.jpg",
	"right": "right.jpg",
	"crash": "crash.jpg",
	"snooze": "snooze.jpg",
}

EMOJI_IMAGE_FILENAMES = {
	"crash": "crash.jpg",
	"eyes_closed": "eyes-closed.jpg",
	"eyes_left": "eyes-left.jpg",
	"eyes_right": "eyes-right.jpg",
	"snooze": "snooze.jpg",
	"eyes_straight": "eyes-straight.jpg",
	"glasses": "glasses.png",
	"oh_no": "oh-no.png",
	"sunglasses": "sunglasses.png",
	"thumbs_up": "thumbs-up.png",
	"thumbs_down": "thumbs-down.png",
}

FONT_TYPES = {
	"FreeSans": "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
	"FreeSansBold": "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
	"FreeSansOblique": "/usr/share/fonts/truetype/freefont/FreeSansOblique.ttf",
	"FreeSansBoldOblique": "/usr/share/fonts/truetype/freefont/FreeSansBoldOblique.ttf",
	"FreeMono": "/usr/share/fonts/truetype/freefont/FreeMono.ttf",
	"FreeSerif": "/usr/share/fonts/truetype/freefont/FreeSerif.ttf",
}

ICON_FILENAMES = {
	"battery-1": "battery-1.jpg",
	"battery-2": "battery-2.jpg",
	"battery-3": "battery-3.jpg",
	"battery-4": "battery-4.jpg",
	"globe-canceled": "globe-canceled.jpg",
	"globe": "globe.jpg",
	"play": "play.jpg",
	"stop": "stop.jpg",
	"wifi-off": "wifi-off.jpg",
	"wifi-on": "wifi-on.jpg",
}
	

# Checks the cache for the key, if not found, runs the update function
def get_from_cache(key, update_function):

	if key in cache:
		value = cache.get(key)
	
	else:
		value = update_function()
		
	return value


# Initializes display and returns pointer
def initialize_screen():

	display = LCD_2inch(
		rst=GPIO_PINS.get("RST"),
		dc=GPIO_PINS.get("DC"),
		bl=GPIO_PINS.get("BL")
	)

	return display


# Shows the passed image on the display
def show_image(display_image):

	# Initialize display
	display = initialize_screen()
	
	# Save the current content image in the cache
	cache.set('image', display_image)

	# Rotate image to reflect robot orientation
	display_image = display_image.rotate(DEFAULT_ROTATION)

	# Check if flag file exists
	if not os.path.exists(DISPLAY_FLAG_FILE_PATH):
		
		# If not, initialize the display and create the flag file
		display.Init()

		# Create the flag file
		with open(DISPLAY_FLAG_FILE_PATH, 'w') as flag_file:
			flag_file.write('Display initialized')

	# Show image
	display.ShowImage(display_image)


# Gets the latest status bar and stores it in the cache
def update_status_bar(battery_level=1, wireless_network=None, program_running=None, internet_connection=None):

	status_bar = create_status_bar(battery_level, wireless_network, program_running, internet_connection)
	cache.set('status_bar', status_bar)
	
	return status_bar


# Creates the status bar
def create_status_bar(battery_level=1, wireless_network=None, program_running=None, internet_connection=None):

	# Create a new image with a white background
	status_bar = Image.new('RGB', (320, STATUS_BAR_HEIGHT), 'white')

	# Calculate icon positions
	icon_padding = 5
	icon_size = 24

	# Time text position (left)
	time_text_x = icon_padding
	time_text_y = icon_padding

	# Calculate positions for other icons (right)
	right_padding = 320  # total width of the status_bar
	battery_icon_x = right_padding - (icon_padding + icon_size)
	battery_icon_y = icon_padding	
	program_icon_x = right_padding - (2 * icon_padding + 2 * icon_size)
	program_icon_y = icon_padding
	connection_icon_x = right_padding - (3 * icon_padding + 3 * icon_size)
	connection_icon_y = icon_padding
	network_icon_x = right_padding - (4 * icon_padding + 4 * icon_size)
	network_icon_y = icon_padding

	# Load image icons
	battery_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", ICON_FILENAMES["battery-" + str(battery_level)]))	
	
	connection_image = ICON_FILENAMES["globe"] if internet_connection == True else ICON_FILENAMES["globe-canceled"]
	connection_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", connection_image))
	
	program_image = ICON_FILENAMES["play"] if program_running == True else ICON_FILENAMES["stop"]
	program_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", program_image))
	
	network_image = ICON_FILENAMES["wifi-on"] if wireless_network == True else ICON_FILENAMES["wifi-off"]
	network_icon = Image.open(os.path.join(DEFAULT_PATH, "images", "icons", network_image))

	# Draw icons on the status bar
	status_bar.paste(battery_icon, (battery_icon_x, battery_icon_y))
	status_bar.paste(connection_icon, (connection_icon_x, connection_icon_y))
	status_bar.paste(program_icon, (program_icon_x, program_icon_y))
	status_bar.paste(network_icon, (network_icon_x, network_icon_y))

	# Draw time text
	draw = ImageDraw.Draw(status_bar)
	font = ImageFont.truetype(FONT_TYPES['FreeSans'], 18)
	time_text = time.strftime("%H:%M", time.localtime())
	draw.text((time_text_x, time_text_y), time_text, font=font, fill=(0, 0, 0))

	return status_bar


def create_blank_content():

	# Create black screen
	display_image = Image.new('RGB', (DISPLAY_WIDTH, DISPLAY_HEIGHT), "white")
	
	return display_image;


def show_status_bar(battery_level=1, wireless_network=None, program_running=None, internet_connection=None):

	# Create a new status bar 
	status_bar = update_status_bar(battery_level, wireless_network, program_running, internet_connection)
	
	# Retrieve the last cashed display image
	display_image = get_from_cache('image', create_blank_content);
	
	# Add new status bar on top of cached image
	display_image.paste(status_bar, (0, 0))
	
	# Output image to display
	show_image(display_image)


# Shows a named color (case insesitive) on the display [140 standard names supported]
def show_color(color="white"):

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Builds the content section
	content_section = Image.new('RGB', (DISPLAY_WIDTH, CONTENT_AREA_HEIGHT), color)

	# Combine the status bar and content sections into a single image
	color_image = Image.new('RGB', (DISPLAY_WIDTH, DISPLAY_HEIGHT), 'black')
	color_image.paste(status_bar, (0, 0))
	color_image.paste(content_section, (0, STATUS_BAR_HEIGHT))

	# Output image to display
	show_image(color_image)


# Shows a named face [from assets folder] on the display
def show_face(selected_face="straight"):

	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)

	# Create background image
	face_image = Image.open(os.path.join(DEFAULT_PATH, "images", "faces", FACE_IMAGE_FILENAMES[selected_face]))
	face_image.paste(status_bar, (0, 0))

	# Output image to display
	show_image(face_image)


def show_emoji(selected_emoji="eyes_straight"):
    DISPLAY_SIZE = (320, 240)
    # Retrieve the last created status bar from the cache
    status_bar = get_from_cache('status_bar', update_status_bar)

    # Create background image
    emoji_path = os.path.join(DEFAULT_PATH, "images", "emojis", EMOJI_IMAGE_FILENAMES[selected_emoji])
    emoji_image = Image.open(emoji_path)

    # Resize the image while maintaining aspect ratio if it's larger than the display
    if emoji_image.size[0] > DISPLAY_SIZE[0] or emoji_image.size[1] > DISPLAY_SIZE[1]:
        emoji_image.thumbnail(DISPLAY_SIZE)

    # Create a new blank (white) image with the display dimensions
    output_image = Image.new('RGBA', DISPLAY_SIZE, (255, 255, 255, 255))

    # Calculate coordinates to center the emoji image
    img_center_x = (DISPLAY_SIZE[0] - emoji_image.size[0]) // 2
    img_center_y = (DISPLAY_SIZE[1] - emoji_image.size[1]) // 2

    # Check if the image has an alpha channel (transparency)
    if 'A' in emoji_image.getbands():
        # Paste the resized and centered emoji image onto the blank image using it as a mask
        output_image.paste(emoji_image, (img_center_x, img_center_y), mask=emoji_image)
    else:
        # Paste the resized and centered emoji image onto the blank image without using it as a mask
        output_image.paste(emoji_image, (img_center_x, img_center_y))

    # Convert the status bar image to RGBA if necessary
    if status_bar.mode != 'RGBA':
        status_bar = status_bar.convert('RGBA')

    # Check if the status bar has an alpha channel (transparency)
    if 'A' in status_bar.getbands():
        # Paste the status bar image onto the new image using it as a mask
        output_image.paste(status_bar, (0, 0), mask=status_bar)
    else:
        # Paste the status bar image onto the new image without using it as a mask
        output_image.paste(status_bar, (0, 0))

    # Convert the image to jpg, discarding the alpha channel
    output_image = output_image.convert('RGB')

    # Output image to display
    show_image(output_image)


# Shows text on the display
def show_text(text="Hello World", color="black", background="white", font_type=DEFAULT_FONT, size=40, min_font_size=10, max_font_size=60, max_chars=500):

    # If text exceeds maximum characters, truncate it
    if max_chars is not None and len(text) > max_chars:
        text = text[:max_chars]

    # Retrieve the last created status bar from the cache
    status_bar = get_from_cache('status_bar', update_status_bar)

    # Create an image for the content section
    content_section = Image.new('RGB', (DISPLAY_WIDTH, CONTENT_AREA_HEIGHT), background)
    draw = ImageDraw.Draw(content_section)

    # Create a temporary image to calculate text dimensions
    temp_img = Image.new('RGB', (DISPLAY_WIDTH, CONTENT_AREA_HEIGHT), background)
    temp_draw = ImageDraw.Draw(temp_img)

    # Get Font
    font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES[font_type]), size)

    # Calculate average character width
    avg_width = sum(font.getsize(char)[0] for char in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz') / 52

    # Measure text and resize if necessary
    min_size, max_size = min_font_size, min(max_font_size, size)  # Set bounds for binary search

    while min_size < max_size:
        size = (min_size + max_size + 1) // 2  # Take the middle value
        font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES[font_type]), size)

        # Calculate characters per line and wrap text
        chars_per_line = int(DISPLAY_WIDTH / (avg_width * size / 40))
        lines = textwrap.wrap(text, width=chars_per_line)
        text_lines = '\n'.join(lines)

        # Check if text fits within dimensions
        text_width, text_height = temp_draw.multiline_textsize(text_lines, font=font)
        if text_width > DISPLAY_WIDTH or text_height > CONTENT_AREA_HEIGHT:
            max_size = size - 1  # If text is too big, reduce the maximum size
        else:
            min_size = size  # If text is not too big, increase the minimum size

    size = min_size  # The final font size
    font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES[font_type]), size)
    chars_per_line = int(DISPLAY_WIDTH / (avg_width * size / 40))
    lines = textwrap.wrap(text, width=chars_per_line)
    text_lines = '\n'.join(lines)

    # Calculate position to center text
    text_width, text_height = temp_draw.multiline_textsize(text_lines, font=font)
    position = ((DISPLAY_WIDTH - text_width) / 2, (CONTENT_AREA_HEIGHT - text_height) / 2)

    # Add text
    draw.multiline_text(position, text_lines, fill=color, font=font, align='center')

    # Combine the status bar and content sections into a single image
    text_image = Image.new('RGB', (DISPLAY_WIDTH, DISPLAY_HEIGHT), 'black')
    text_image.paste(status_bar, (0, 0))
    text_image.paste(content_section, (0, status_bar.height))

    # Output image to display
    show_image(text_image)


# Shows a splash screen on the display
def show_splash_screen():
	
	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)
	
	# Fetch current version and generate image
	update_version()
	version_image = create_version_image()

	# Create background image
	splash_screen = Image.open(os.path.join(DEFAULT_PATH, "images", "splash.jpg"))
	splash_screen.paste(status_bar, (0, 0))
	splash_screen.paste(version_image, (20, 210))

	# Output image to display
	show_image(splash_screen)


# Shows an end screen on the display (meant for when powering off)
def show_end_screen():
	
	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)
	
	# Retrieve the last created version image from the cache
	version_image = create_version_image()

	# Create background image
	end_screen = Image.open(os.path.join(DEFAULT_PATH, "images", "splash.jpg"))
	end_screen.paste(status_bar, (0, 0))
	end_screen.paste(version_image, (20, 210))
	
	# Output image to display
	show_image(end_screen)

# Show wifi connection instructions on display
def show_connect_screen(ssid="Recruit_AP123", password="mrirecruit", url="my.bot", uap0_address="", wlan0_address=""):

    # Define local variables
    instructions = [
        "Ready to Connect",
        "1. Connect to: " + ssid,
        "2. Enter Password: " + password,
        "3. Open your: web browser",
        "4. Visit: " + url
    ]
    ip_address_image_height = 20
    instructions_font_size = 20
    instructions_header_font_size = 24
    instructions_line_spacing = 15
    ip_address_font_size = 15
    rgb_color = ImageColor.getrgb(BRAND_PRIMARY_COLOR)

    # Retrieve the last created status bar from the cache
    status_bar = get_from_cache('status_bar', update_status_bar)

    # Builds the content section
    content_section = Image.new('RGB', (DISPLAY_WIDTH, CONTENT_AREA_HEIGHT), rgb_color)

    # Create the two new images to be pasted onto the content_section
    
    # First image will occupy the full height except the last 20 pixels
    instructions_image_height = CONTENT_AREA_HEIGHT - ip_address_image_height
    instructions_image = Image.new('RGBA', (DISPLAY_WIDTH, instructions_image_height), rgb_color)
    instructions_image_drawer = ImageDraw.Draw(instructions_image)

    # Second image will take the remaining 20 pixels at the bottom
    ip_address_image = Image.new('RGBA', (DISPLAY_WIDTH, ip_address_image_height), rgb_color)
    ip_address_image_drawer = ImageDraw.Draw(ip_address_image)

    # Pepare the fonts
    instructions_header_font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES['FreeSansBold']), instructions_header_font_size)
    instructions_font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES['FreeSans']), instructions_font_size)
    instructions_bold_font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES['FreeSansBold']), instructions_font_size)
    ip_address_font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES['FreeSans']), ip_address_font_size)

    # Draw the instructions on the first image
    text_height = instructions_image_drawer.textsize("Test", font=instructions_font)[1]  # Calculate height of the text
    total_text_height = len(instructions) * text_height + (len(instructions) - 1) * instructions_line_spacing  # Account for spacing
    start_y_position = (instructions_image_height - total_text_height) / 2  # Start drawing from this y-position to center the instructions
    for i, instruction in enumerate(instructions):
        y_position = start_y_position + i * (text_height + instructions_line_spacing)  # Include spacing in the y-position
        if i == 0:
            instructions_image_drawer.text((10, y_position), instruction, fill="white", font=instructions_header_font)
        else:
            if ":" in instruction:
            	parts = instruction.split(":")
	    	instructions_image_drawer.text((10, y_position), parts[0] + ": ", fill="white", font=instructions_font)
	    	instructions_image_drawer.text((10 + instructions_image_drawer.textsize(parts[0] + ": ", font=instructions_font)[0], y_position), parts[1].strip(), fill="white", font=instructions_bold_font)
	    else:
	    	instructions_image_drawer.text((10, y_position), instruction, fill="white", font=instructions_font)

    # Draw the IP addresses on the second image
    ip_address_image_drawer.text((10, 2), uap0_address, fill="white", font=ip_address_font) 
    ip_address_image_drawer.text((DISPLAY_WIDTH - 10 - ip_address_image_drawer.textsize(wlan0_address, font=ip_address_font)[0], 2), wlan0_address, fill="white", font=ip_address_font)

    # Paste the new images onto the content_section
    content_section.paste(instructions_image, (0, 0))
    content_section.paste(ip_address_image, (0, instructions_image_height))

    # Combine the status bar and content sections into a single image
    connect_screen_image = Image.new('RGB', (DISPLAY_WIDTH, DISPLAY_HEIGHT), 'black')
    connect_screen_image.paste(status_bar, (0, 0))
    connect_screen_image.paste(content_section, (0, status_bar.height))

    # Output image to display
    show_image(connect_screen_image)


# Retrieves the mybot's tagged version and stores it in cache
def update_version():
	
	# Retrieve version
	working_directory = "/usr/Fusion"
	output = subprocess.check_output(['git', '-C', working_directory, 'describe', '--tags', '--abbrev=0'], stderr=subprocess.STDOUT)
	latest_tag = output.strip()
	
	# Store version info in cache
	cache.set('mybot_version', latest_tag)
	
	return latest_tag


# Creates a version image from the latest git tag
def create_version_image(background_color="white", font_color="black"):
	
	# Get Font
	font = ImageFont.truetype(os.path.join(DEFAULT_PATH, "fonts", FONT_TYPES[DEFAULT_FONT]), 14)
	
	# Retrieve the last version tag from cache
	version_tag = get_from_cache('mybot_version', update_version)
	
	# Create version image
	version_image = Image.new('RGB', (100, 14), background_color)
	draw = ImageDraw.Draw(version_image)
	draw.text((0, 0), version_tag, fill=font_color, font=font)
	
	return version_image


# Show idle screen
def show_idle_screen():
	
	# Retrieve the last created status bar from the cache
	status_bar = get_from_cache('status_bar', update_status_bar)
	
	# Create the version image
	rgb_color = ImageColor.getrgb(BRAND_PRIMARY_COLOR)
	version_image = create_version_image(background_color=rgb_color, font_color="white")

	# Create the display image
	idle_screen = Image.open(os.path.join(DEFAULT_PATH, "images", "idle.jpg"))
	idle_screen.paste(status_bar, (0, 0))
	idle_screen.paste(version_image, (18, 215))

	# Output image to display
	show_image(idle_screen)