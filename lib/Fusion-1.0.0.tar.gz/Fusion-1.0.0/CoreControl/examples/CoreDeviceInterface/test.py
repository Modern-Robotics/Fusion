import CoreControl

d = CoreControl.driver()