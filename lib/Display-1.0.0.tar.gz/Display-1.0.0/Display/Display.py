import os
from enum import Enum
from lcddisplay import LCD_2inch
from PIL import Image, ImageDraw, ImageFont

defaultPath = os.path.join(os.path.dirname(__file__), "assets")
defaultRotation = 180

faces = {
	"straight": "straight.jpg",
	"left": "left.jpg",
	"right": "right.jpg",
	"crash": "crash.jpg",
	"snooze": "snooze.jpg"
}

emojis = {
	"crash": "Crash.jpg",
	"eyes_closed": "EyesClosed.jpg",
	"eyes_left": "EyesLeft.jpg",
	"eyes_right": "EyesRight.jpg",
	"snooze": "Snooze.jpg",
	"eyes_straight": "Straight.jpg",
}

fontTypes = {
	0: "Font00.ttf",
	1: "Font01.ttf",
	2: "Font02.ttf"
}

# Initilazies display and returns pointer
def initializeScreen():
	disp = LCD_2inch.LCD_2inch()
	disp.Init()
	disp.clear()
	return disp
	

# Shows a named color (case insesitive) on the display [140 standard names supported]
def showColor(color="white"):

	# Initialize display
	disp = initializeScreen()
	
	# Create background color
	image = Image.new("RGB", (disp.height, disp.width ), color)
	draw = ImageDraw.Draw(image)
	
	# Show image
	disp.ShowImage(image)


# Shows a named face [from assets folder] on the display
def showFace(selectedFace="straight"):

	# Initialize display
	disp = initializeScreen()
	
	# Create background image
	image = Image.open(os.path.join(defaultPath, "images", "faces", faces[selectedFace]))
	
	# Rotate image to reflect robot orientation
	image = image.rotate(defaultRotation)
	
	# Show image
	disp.ShowImage(image)


# Shows a named emoji [from assets folder] on the display
def showEmoji(selectedEmoji="eyes_straight"):

	# Initialize display
	disp = initializeScreen()
	
	# Create background image
	image = Image.open(os.path.join(defaultPath, "images", "emojis", emojis[selectedEmoji]))
	
	# Rotate image to reflect robot orientation
	image = image.rotate(defaultRotation)
	
	# Show image
	disp.ShowImage(image)


# Shows text on the display
def showText(text="Hello World", color="black", background="white", fontType=0, size=40, position=(40,90)):

	# Initialize display
	disp = initializeScreen()
	
	# Get Font
	font = ImageFont.truetype(os.path.join(defaultPath, "fonts", fontTypes[fontType]), size)
	
	# Create background color
	image = Image.new("RGB", (disp.height, disp.width ), background)
	draw = ImageDraw.Draw(image)
	
	# Add text
	draw.text(position, text, fill=color, font=font)
	
	# Rotate image to reflect robot orientation
	image = image.rotate(defaultRotation)
	
	# Show image
	disp.ShowImage(image)


# Shows a splash screen on the display
def showSplashScreen():

	# Initialize display
	disp = initializeScreen()
		
	# Create background image
	image = Image.open(os.path.join(defaultPath, "images", "Welcome3.jpg"))
	
	# Rotate image to reflect robot orientation
	image = image.rotate(defaultRotation)
	
	# Show image
	disp.ShowImage(image)


# Shows an end screen on the display (meant for when powering off)
def showEndScreen():

	# Initialize display
	disp = initializeScreen()
	
	# Create background image
	image = Image.open(os.path.join(defaultPath, "images", "Welcome3.jpg"))
	
	# Rotate image to reflect robot orientation
	image = image.rotate(defaultRotation)
	
	# Show image
	disp.ShowImage(image)


# Show wifi connection instructions on display
def showConnectScreen(ssid="Recruit_AP123", password="mrirecruit", url="my.bot", fontType=0, size=25, background="white", color="black"):

	# Initialize display
	disp = initializeScreen()
	
	# Get Font
	font = ImageFont.truetype(os.path.join(defaultPath, "fonts", fontTypes[fontType]), size)
	
	# Create background color
	image = Image.new("RGB", (disp.height, disp.width ), background)	
	draw = ImageDraw.Draw(image)
	
	# Add text
	draw.text((10, 20), "Connect to Acess Point", fill=color, font=font)
	draw.text((10, 60), "SSID: " + ssid, fill=color, font=font)
	draw.text((10, 100), "Password: " + password, fill=color, font=font)
	draw.text((10, 140), "URL: " + url, fill=color, font=font)
	
	# Rotate image to reflect robot orientation
	image = image.rotate(defaultRotation)
	
	# Show image
	disp.ShowImage(image)


# Show idle screen when waiting for user input
def showIdleScreen():

	# Initialize display
	disp = initializeScreen()
	
	# Create background image
	image = Image.open(os.path.join(defaultPath, "images", "Welcome1.jpg"))
	
	# Rotate image to reflect robot orientation
	image = image.rotate(defaultRotation)
	
	# Show image
	disp.ShowImage(image)

