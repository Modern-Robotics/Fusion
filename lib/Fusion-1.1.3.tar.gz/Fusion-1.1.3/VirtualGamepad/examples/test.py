import Fusion
import VirtualGamepad
import time 

f = Fusion.driver()
w = VirtualGamepad
w.startServer() 

counter = 0 

while True:
    (x, y) = w.leftJoystick()
    w.telemetry(0, "x value = " + str(x))
    w.telemetry(1, "y value = " + str(y))
    
    left_motor = y + x
    if(left_motor >= 100): left_motor = 100
    elif (left_motor <= -100): left_motor = -100
    
    right_motor = y - x
    if(right_motor >= 100): right_motor = 100 
    elif(right_motor <= -100): right_motor = -100
    
    f.motorSpeed(f.M0, left_motor)
    f.motorSpeed(f.M1, right_motor)