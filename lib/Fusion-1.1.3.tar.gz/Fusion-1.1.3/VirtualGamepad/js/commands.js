var origin = String(document.location.origin).slice(7)
var index = origin.indexOf(':')
var socketAddress = "ws://" + origin.slice(0, index) + ":12345/"
var ws = new WebSocket(socketAddress);

var w = window,
    d = document,
    e = d.documentElement,
    g = d.getElementsByTagName('body')[0],
    screen_x = w.innerWidth || e.clientWidth || g.clientWidth,
    screen_y = w.innerHeight|| e.clientHeight|| g.clientHeight;
    
var joy1x_offset = 100
var joy1y_offset = 100
var joy2x_offset = 100
var joy2y_offset = 100

var outgoing_data = '';
    
var joystick1 = new VirtualJoystick({
    container       : document.body,
    mouseSupport    : true,
    limitStickTravel: true,
    stickRadius     : 50,
    stationaryBase  : true,
    baseX           : joy1x_offset,
    baseY           : screen_y - joy1y_offset,
    useCSStransform : true
});

var joystick2 = new VirtualJoystick({
    container       : document.body,
    mouseSupport    : true,
    limitStickTravel: true,
    stickRadius     : 50,
    stationaryBase  : true,
    baseX           : screen_x - joy2x_offset,
    baseY           : screen_y - joy2y_offset,
    useCSStransform : true
});

joystick1.addEventListener('touchStartValidation', function(event){
    var touch = event.changedTouches[0];
    if( touch.pageX >= window.innerWidth/2 ) return false;
    return true
});

joystick2.addEventListener('touchStartValidation', function(event){
    var touch = event.changedTouches[0];
    if( touch.pageX < window.innerWidth/2 ) return false;
    return true
});

function controlBot() {
    outgoing_data = ''
    if(joystick1._pressed){
        outgoing_data += (Math.ceil(joystick1.deltaX()) + ' ' + Math.ceil(joystick1.deltaY()) + ' ');
    }
    else{
        outgoing_data += '0 0 ';
    }
    
    if(joystick2._pressed){
        outgoing_data += (Math.ceil(joystick2.deltaX()) + ' ' + Math.ceil(joystick2.deltaY()) + ' ');
    }
    else{
        outgoing_data += '0 0 ';
    }
    ws.send(outgoing_data);
};

ws.onmessage = function(e){
    var telemetry = document.getElementById('telemetry');
    telemetry.innerHTML = '<b>Telemetry:</b> <br />' + e.data;
    console.log(e.data);
};

setInterval(function(){    
    // Screen scaling ---------------------------------------------------------
    screen_x = w.innerWidth || e.clientWidth || g.clientWidth;
    screen_y = w.innerHeight|| e.clientHeight|| g.clientHeight;
    
    // Joystick 1    
    joystick1._baseX = joy1x_offset;
    joystick1._baseY = screen_y - joy1y_offset;
    joystick1.updateLocation();
    
    // Joystick 2
    joystick2._baseX = screen_x - joy2x_offset;
    joystick2._baseY = screen_y - joy2y_offset;
    joystick2.updateLocation();
    
    // Function to send updated joystick data ---------------------------------
    controlBot();
    }, 100);