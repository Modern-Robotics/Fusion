#!/usr/bin/python
from SimpleWebSocketServer import WebSocket, SimpleWebSocketServer
import time
import traceback
from threading import Thread
import socket
import SimpleHTTPServer
import SocketServer
import os
import subprocess    

# Get the absolute path for linking files and folders to module
abs_path = os.path.abspath(__file__)
if '__init__.' in abs_path:
    lib_path = abs_path[:abs_path.index('__init__.')]
    
# Global variables
incomming_data = ""
outgoing_buffer = [None]*20
outgoing_data = None
connected = False
data_array = [] 

def leftJoystick():
    global data_array
    time.sleep(0.001)
    try:
        return (data_array[0]*2, data_array[1]*2);
    except:
        return(0, 0);
    
def rightJoystick():
    global data_array
    time.sleep(0.001)
    try:
        return (data_array[2]*2, data_array[3]*2);
    except:
        return(0, 0);
        
def telemetry(line, value):
    global outgoing_buffer
    outgoing_buffer[line] = value
    return;

class SimpleEcho(WebSocket):
  def handleMessage(self):
    global incomming_data, outgoing_data, outgoing_buffer
    global data_array
    
    incomming_data = self.data
    if(incomming_data != None):
        data_array = incomming_data.split()
        data_array = map(int, data_array)
      
    outgoing_data = ''
    for i in range(len(outgoing_buffer)):
        if(outgoing_buffer[i] != None):
            outgoing_data += str(outgoing_buffer[i]) + '<br />'
    if(outgoing_data != ''): self.sendMessage(outgoing_data)
    
  def handleConnected(self): 
    global connected 
    connected = True
    print self.address, 'connected'

  def handleClose(self):
    global connected 
    connected = False
    print self.address, 'closed'

def controlThread():
    global control_object
    try:
        control_object = SimpleWebSocketServer('', 12345, SimpleEcho)
        control_object.serveforever()
    except:
        print traceback.format_exc(1)
        control_object.close()

class MyTCPServer(SocketServer.TCPServer):
    def server_bind(self):
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind(self.server_address)

class MyHTTPRequestHandler(SimpleHTTPServer.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_my_headers()
        SimpleHTTPServer.SimpleHTTPRequestHandler.end_headers(self)

    def send_my_headers(self):
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        
    def translate_path(self,path):
        path = SimpleHTTPServer.SimpleHTTPRequestHandler.translate_path(self,path)
        if (os.path.isdir(path)):
            return lib_path 
        if '/misc' in path:
            return lib_path + path[path.find('misc'):];
        if '/css' in path:
            return lib_path + path[path.find('css'):];
        if '/js' in path:
            return lib_path + path[path.find('js'):];
        return path
        
def serverThread():
    s = MyHTTPRequestHandler
    httpd = MyTCPServer(("", 5000), s)
    httpd.serve_forever()
    
def startServer(camera=False, resolution=(320,240), frame_rate=10):
    try:        
        if(camera == True):
            os.system('LD_LIBRARY_PATH=' + lib_path + 'mjpg-streamer mjpg_streamer -i "input_uvc.so -r ' + str(resolution[0]) + 'x' + str(resolution[1]) +' -f ' + str(frame_rate) + '" -o "output_http.so -p 9080" &')
        
        server_thread = Thread(target=serverThread, args=())
        server_thread.daemon = True 
        server_thread.start() 
        
        control_thread = Thread(target=controlThread, args=())
        control_thread.daemon = True
        control_thread.start()
        print "Server now running..."
        
    except:
        print traceback.format_exc(1)        