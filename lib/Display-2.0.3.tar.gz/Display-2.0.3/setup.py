from setuptools import setup

setup(
	name = "Display",
	version = "2.0.3",
	author = "Boxlight",
	author_email = "support@modernroboticsinc.com",
	description = "A Python module to control the connect display",
    url = "modernroboticsinc.com",
	packages = ["Display"]
)