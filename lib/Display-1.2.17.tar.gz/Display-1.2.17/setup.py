from setuptools import setup

setup(
	name = "Display",
	version = "1.2.17",
	author = "Boxlight",
	author_email = "support@modernroboticsinc.com",
	description = "A Python module to control the connect display",
    url = "modernroboticsinc.com",
	packages = ["Display"],
	package_data={"Display": [
		"assets/**/*",
    	"assets/fonts/**/*",
        "assets/images/**/*",
		"assets/icons/**/*"
    ]},
)